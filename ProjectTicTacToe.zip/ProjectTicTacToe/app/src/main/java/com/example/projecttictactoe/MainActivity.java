package com.example.projecttictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    //Valuables
    DataBaseHelper db;
    EditText email;
    EditText password;
    EditText conPassword;
    Button signUp;
    Button signIn;


    @Override
    //Creates Instans for the DataBase

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Using the db from the values from above.

        db = new DataBaseHelper(this);

        //Getting the id's in the Layout section for the MainActivity

        email = (EditText)findViewById(R.id.email);
        password = (EditText)findViewById(R.id.pass);
        conPassword = (EditText)findViewById(R.id.conpass);
        signUp = (Button)findViewById(R.id.signup);
        signIn = (Button)findViewById(R.id.signin);

        //Here we are creating a intention that will lead to the next activity which is  the Login

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,Login.class);
                startActivity(i);
            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Here we need to full in the users: Email,Password and last to Confirm Password
                //After that we are creating cases to check if the required values are typed in

                String s1 = email.getText().toString();
                String s2 = password.getText().toString();
                String s3 = conPassword.getText().toString();

                //Checking if the values from above are full or not

                if (s1.equals("") || s2.equals("") || s3.equals("")){

                    //Displaies a message that their are no information fulled in

                    Toast.makeText(getApplicationContext(),"Fields are empty",Toast.LENGTH_SHORT).show();
                }
                else {

                    //Here we are creating a case to see if the passwords match : type bool (true or false)

                    if(s2.equals(s3)){
                        Boolean checkEmail = db.checkEmail(s1);

                        //If the passwords from the above match then insert the in the DataBase

                        if(checkEmail == true){
                            Boolean insert = db.insert(s1,s2);

                            //Here we create a case to see if the inserted data was put out DataBase file

                            if(insert == true){

                                //Displaies a message that we have successfullt made an registration

                                Toast.makeText(getApplicationContext(),"Registered Successfully",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{

                            //Displaies a message that the email exists

                            Toast.makeText(getApplicationContext(),"Email already exists",Toast.LENGTH_SHORT).show();
                        }
                    }

                    //Displaies a message if we didnt match our passwords

                    Toast.makeText(getApplicationContext(),"Password doesn't match",Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
}
