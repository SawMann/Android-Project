package com.example.projecttictactoe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class TicTacToe extends AppCompatActivity implements View.OnClickListener {


    //Valuables (Note: We are creating buttons with arrays)
    private Button [][] buttons = new Button[3][3];
    private  boolean player1Turn = true;
    private int roundCounts;
    private int player1Points;
    private int player2Points;
    private TextView textViewPlayer1;
    private TextView textViewPlayer2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tic_tac_toe);

        //Getting the id's from the Layout section in the TicTacToe Activity
        textViewPlayer1 = findViewById(R.id.viewPlayer1);
        textViewPlayer2 = findViewById(R.id.viewPlayer2);


        //Creating a loop
        for(int i = 0;i<3;i++){
            for(int j = 0;j<3;j++){
                String buttonID = "Button_" + i + j;
                int resID = getResources().getIdentifier(buttonID,"id",getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(this);
            }
        }

        //Here we are initializing the button reset
        final Button reset = findViewById(R.id.resetButton);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });
    }


    @Override

    //Here we are creating cases for the first player (which is the loged in user )to start his turn

    public void onClick(View v) {
        if(!((Button) v).getText().toString().equals("")){
            return;
        }
        if(player1Turn){
            ((Button) v).setText("X");
        }
        else{
            ((Button) v).setText("O");
        }
        roundCounts++;

        //Creating a case for who the winner is
        if(checkWin()){
            if(player1Turn){
                player1Wins();
            }
            else {
                player2Wins();
            }
        }

        //Here the Game is a draw when all the blocks are filled and there are no winners

        else if(roundCounts == 9){
            draw();
        }
        else {
            player1Turn = !player1Turn;
        }
    }

    //Here its explaned in the documentary
    private boolean checkWin(){
        String [][] field = new String[3][3];
        for(int i = 0 ; i < 3; i++){
            for(int j = 0; j < 3 ; j++){
                field[i][j] = buttons[i][j].getText().toString();
            }
        }
        for(int i=0; i < 3;i++){
            if(field[i][0].equals(field[i][1]) && field[i][0].equals(field[i][2]) && !field[i][0].equals("")){
                    return true;
            }
        }
        for(int i = 0 ;i < 3; i++){
            if(field[0][i].equals(field[1][i]) && field[0][i].equals(field[2][i]) && !field[0][i].equals("")){
                return true;
            }
        }

        if(field[0][0].equals(field[1][1]) && field[0][0].equals(field[2][2]) && !field[0][0].equals("")){
            return true;
        }
        if(field[0][2].equals(field[1][1]) && field[0][2].equals(field[2][0]) && !field[0][2].equals("")){
            return true;
        }
        return false;
    }

    //Here we create a method to keep a track in the player's points
    private void updatePoints(){
        textViewPlayer1.setText("Player 1: " + player1Points);
        textViewPlayer2.setText("Player 2: " + player2Points);
    }

    //Creating a method that restards the board
    private void resetBoard(){
        for(int i = 0; i < 3 ; i++){
            for(int j = 0 ; j < 3 ; j++){
                buttons[i][j].setText("");
            }
        }
        roundCounts = 0;
        player1Turn = true;
    }

    //Adds the points to the winner and displaing a message
    private void player1Wins(){
        player1Points++;
        Toast.makeText(this,"Player 1 wins",Toast.LENGTH_SHORT).show();
        updatePoints();
        resetBoard();
    }

    //Adds the points to the winner and displaing a message
    private void player2Wins(){
        player2Points++;
        Toast.makeText(this,"Player 2 wins",Toast.LENGTH_SHORT).show();
        updatePoints();
        resetBoard();
    }

    //Displaying a message that the game is Draw
    private void draw(){
        Toast.makeText(this,"Draw",Toast.LENGTH_SHORT).show();
        resetBoard();
    }

    //The method resets the Game
    private void resetGame(){
        player1Points = 0;
        player2Points = 0;
        updatePoints();
        resetBoard();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("roundCount",roundCounts);
        outState.putInt("Player 1 s points:",player1Points);
        outState.putInt("Player 2's points:",player2Points);
        outState.putBoolean("Player 1's Turn",player1Turn);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        roundCounts = savedInstanceState.getInt("roundCount");
        player1Points = savedInstanceState.getInt("Player 1's points");
        player2Points = savedInstanceState.getInt("Player 2's points");
        player1Turn = savedInstanceState.getBoolean("player1Turn");
    }
}
