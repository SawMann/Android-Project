package com.example.projecttictactoe;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataBaseHelper extends SQLiteOpenHelper {

    public DataBaseHelper(@Nullable Context context) {
        super(context, "Login.db",null,1);

    }
    @Override

    //Creating the table

    public void onCreate(SQLiteDatabase db) {

        db.execSQL("Create table user(email text primary key,password text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists user");
    }

    //Now we will start inserting in the database

    public boolean insert(String email,String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValue = new ContentValues();
        contentValue.put("email",email);
        contentValue.put("password",password);
        long ins = db.insert("user",null,contentValue);

        //Ctreating a case if there are no user's in the DataBase

        if (ins == -1){
            return false;
        }
        else {
            return true;
        }
    }


    //Here we check if the email exists

    public Boolean checkEmail(String emailSet){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from user where email =?",new String[]{emailSet});
        if(cursor.getCount()>0){
            return false;
        }
        else {
            return true;
        }
    }


    //Here we will check the password and the email

    public Boolean emailPasswordCheck (String emailGet, String passGet){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from user where email =? and password =?",new String[]{emailGet,passGet});
        if(cursor.getCount()>0){
            return true;
        }
        else{
            return false;
        }
    }

}
