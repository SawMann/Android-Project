package com.example.projecttictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    //Valuables
    EditText email2;
    EditText password2;
    Button signIn;
    DataBaseHelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Here we use the DataBase

        db = new DataBaseHelper(this);

        //Creating the id's in the layout section for the Login Activity

        email2 = (EditText) findViewById(R.id.email2);
        password2 = (EditText) findViewById(R.id.pass2);
        signIn = (Button) findViewById(R.id.signin2);
        signIn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                //Here we put in the information from the Sigh Up section

                String emailGet = email2.getText().toString();
                String passGet = password2.getText().toString();

                //Here we check if the Email and Password are matched in DataBase.
                Boolean checkEmailPass = db.emailPasswordCheck(emailGet,passGet);
                if(checkEmailPass == true){

                    //Here we display a message to the phone user that we have successfully logged in our account

                    Toast.makeText(getApplicationContext(), "Successfully Logged in",Toast.LENGTH_SHORT).show();

                    //Calling the method that will lead to the game after we press "Login"

                    openTicTacToeGame();
                }
                else{

                    //Displaies a message that we have made a mistake in our password or email

                    Toast.makeText(getApplicationContext(),"Wrong email or password",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    //This method leads to the next activity

    public void  openTicTacToeGame(){
        Intent intent = new Intent(this, TicTacToe.class);
        startActivity(intent);
    }
}
